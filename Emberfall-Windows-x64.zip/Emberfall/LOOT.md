# Łup z przeciwników — Emberfall 0.47

Szansę wyznacza **wyłącznie rzadkość przedmiotu**. Rodzaj przedmiotu, jego siła, ulepszenie i gatunek bestii nie zmieniają tej szansy. Tabela gatunku określa tylko, jakie przedmioty może on pozostawić i ile sztuk zawiera udany stos.

| Rzadkość | Kolor nazwy | Szansa na przedmiot |
|---|---|---|
| Pospolity | biały | 60% |
| Rzadki | niebieski | 15% |
| Bardzo rzadki | żółty | 4% |
| Niezwykle rzadki | fioletowy | 1% |

Każda pozycja jest losowana **niezależnie raz przy śmierci**. Wilk może pozostawić kieł i sierść jednocześnie: każdy stos ma 60%, a szansa na oba to 36%. Monety i mikstury także są losowe. Możliwe jest puste ciało; otwarcie i zamknięcie nie losuje łupu ponownie.

**Wyjątek fabularny zaakceptowany przez gracza:** Część Serca Świtu jest niezwykle rzadka, ale ma gwarantowany drop 100%. Oba istniejące bossy zawsze pozostawiają dokładnie jeden właściwy fragment. Jest w piątym polu pierwszej strony. Zbierz inne nagrody przed fragmentem: zabranie go rozpoczyna powrót do wieży.

Podejdź do ciała na maksymalnie 2,5 pola i otwórz je PPM. Przeciągnij przedmioty do plecaka. Większy łup ma do trzech stron po pięć kratek: przyciski < / > lub rolka myszy nad oknem ciała. Każdy przedmiot ma kolorową nazwę, opis rzadkości i szansę w podpowiedzi. Stosy materiałów, monet, mikstur i strzał mieszczą do 99 sztuk.

## Okrągłe tarcze i zamknięte hełmy

| Kraina | Przedmiot | Pancerz | Przeciwnik | Rzadkość | Szansa z ciała |
|---|---|---:|---|---|---:|
| Las | Krąg żelaznego drewna | +7 | Ożywione drzewo | Rzadki | 15% |
| Las | Hełm nitowanej straży | +7 | Szkielet | Rzadki | 15% |
| Pustynia | Słoneczny dysk wydm | +11 | Skarabeusz miedziany | Bardzo rzadki | 4% |
| Pustynia | Przyłbica słonecznej warty | +11 | Oko Wydm | Bardzo rzadki | 4% |
| Kaldera | Obsydianowy krąg kuźni | +15 | Rogacz Żaru | Niezwykle rzadki | 1% |
| Kaldera | Hełm popielnej kuźni | +15 | Obsydianowy wojownik | Niezwykle rzadki | 1% |

## Dziesięć dodatkowych pancerzy

| Kraina | Pancerz | Obrona | Przeciwnik | Rzadkość | Szansa z ciała |
|---|---|---:|---|---|---:|
| Las | Przeszywanica rozbójników | +5 | Leśny rozbójnik | Pospolity | 60% |
| Las | Pancerz zarodnikowej kniei | +7 | Zarodnik kniei | Rzadki | 15% |
| Las | Kiryś żywej kory | +10 | Ożywione drzewo | Bardzo rzadki | 4% |
| Pustynia | Pancerz łuskowy wydm | +7 | Skarabeusz miedziany | Pospolity | 60% |
| Pustynia | Pancerz bursztynowego żądła | +10 | Skorpion bursztynowy | Rzadki | 15% |
| Pustynia | Kiryś Słonecznej Pieczęci | +14 | Żywa Wydma | Niezwykle rzadki | 1% |
| Kaldera | Brygantyna popielna | +9 | Żużlowy pełzacz | Pospolity | 60% |
| Kaldera | Pancerz Rogacza Żaru | +12 | Rogacz Żaru | Rzadki | 15% |
| Kaldera | Zbroja obsydianowej straży | +14 | Obsydianowy wojownik | Bardzo rzadki | 4% |
| Kaldera | Pancerz Serca Rozłamu | +17 | Varkhor, Serce Kaldery | Niezwykle rzadki | 1% |

## Broń z trzech krain

| Kraina | Broń | Typ | Atak | Przeciwnik | Rzadkość | Szansa z ciała |
|---|---|---|---:|---|---|---:|
| Las | Miecz cierniowego szlaku | Miecz | +15 | Szkielet | Pospolity | 60% |
| Las | Sztylet fioletowej grzybni | Sztylet | +16 | Zarodnik kniei | Rzadki | 15% |
| Las | Topór kamiennej przysięgi | Topór | +23 | Kamienny Strażnik | Niezwykle rzadki | 1% |
| Pustynia | Łuk trzcinowej oazy | Łuk | +16 | Kobra piaskowa | Pospolity | 60% |
| Pustynia | Szabla pękniętego mirażu | Miecz | +24 | Oko Wydm | Bardzo rzadki | 4% |
| Pustynia | Sztylet słonecznego szkła | Sztylet | +19 | Skorpion bursztynowy | Rzadki | 15% |
| Kaldera | Topór żużlowego haka | Topór | +19 | Żużlowy pełzacz | Pospolity | 60% |
| Kaldera | Łuk Rogacza Żaru | Łuk | +24 | Rogacz Żaru | Rzadki | 15% |
| Kaldera | Miecz lawowej żyły | Miecz | +27 | Obsydianowy wojownik | Bardzo rzadki | 4% |
| Kaldera | Łuk Serca Kaldery | Łuk | +32 | Varkhor, Serce Kaldery | Niezwykle rzadki | 1% |

## Dziesięć dodatkowych broni

Każda z tych broni może pojawić się w skrzyni w dowolnej krainie. Skrzynia
nadal wybiera pospolity sprzęt w 75% przypadków i rzadki w 25%, a następnie
losuje przedmiot z odpowiedniej puli. Miron sprzedaje wszystkie dziesięć
broni na trzeciej i czwartej stronie oferty. Istniejące zapisy zachowują
zawartość wcześniej wylosowanych skrzyń i ciał. Żywi przeciwnicy używają
nowych tabel po pokonaniu.

| Broń | Rzadkość | Atak | Przeciwnik | Szansa z ciała | Cena u Mirona |
|---|---|---:|---|---:|---:|
| Tasak starego traktu | Pospolity | +10 | Leśny rozbójnik | 60% | 160 |
| Łuk brzozowej polany | Pospolity | +15 | Wilk | 60% | 200 |
| Miedziany toporek | Pospolity | +10 | Skarabeusz miedziany | 60% | 160 |
| Krzemienny sztylet | Pospolity | +10 | Leśny pająk | 60% | 160 |
| Miecz porannej rosy | Rzadki | +14 | Ożywione drzewo | 15% | 384 |
| Miecz słonecznego szlaku | Rzadki | +18 | Kobra piaskowa | 15% | 448 |
| Topór bazaltowej kuźni | Rzadki | +20 | Obsydianowy wojownik | 15% | 480 |
| Sztylet szklistego żaru | Rzadki | +16 | Salamandra lawowa | 15% | 416 |
| Łuk bursztynowej oazy | Rzadki | +18 | Skorpion bursztynowy | 15% | 448 |
| Łuk popielnego wiatru | Rzadki | +20 | Żarowy drak | 15% | 480 |

## Szlam

| Przedmiot | Rzadkość | Szansa | Liczba sztuk |
|---|---|---|---|
| Złote monety | Pospolity | 60% | 4–15 |
| Śluz szlama | Pospolity | 60% | 1–3 |
| Mikstura zdrowia | Pospolity | 60% | 1 |
| Odłamek echa | Rzadki | 15% | 1–2 |
| Bursztynowy amulet | Rzadki | 15% | 1 |
| Amulet szmaragdowej kropli | Rzadki | 15% | 1 |
| Ostrze zielonej kropli | Pospolity | 60% | 1 |
| Kaptur mglistego runa | Rzadki | 15% | 1 |
| Pierścień bursztynowego żelu | Bardzo rzadki | 4% | 1 |

## Wilk

| Przedmiot | Rzadkość | Szansa | Liczba sztuk |
|---|---|---|---|
| Złote monety | Pospolity | 60% | 4–15 |
| Kieł wilka | Pospolity | 60% | 1–2 |
| Sierść wilka | Pospolity | 60% | 1–2 |
| Mikstura zdrowia | Pospolity | 60% | 1 |
| Sztylet wilczego kła | Rzadki | 15% | 1 |
| Płaszcz tropiciela | Rzadki | 15% | 1 |
| Łuk księżycowego łowcy | Bardzo rzadki | 4% | 1 |
| Kaptur szarego wilka | Pospolity | 60% | 1 |
| Buty srebrnego tropu | Rzadki | 15% | 1 |
| Amulet wilczego serca | Niezwykle rzadki | 1% | 1 |

## Szkielet

| Przedmiot | Rzadkość | Szansa | Liczba sztuk |
|---|---|---|---|
| Złote monety | Pospolity | 60% | 4–15 |
| Fragment kości | Pospolity | 60% | 1–3 |
| Sztylet łowcy | Rzadki | 15% | 1 |
| Mikstura many | Pospolity | 60% | 1 |
| Hełm kościanej straży | Rzadki | 15% | 1 |
| Miecz zapomnianej krypty | Bardzo rzadki | 4% | 1 |
| Tarcza kościanych odłamków | Pospolity | 60% | 1 |
| Pancerz strażnika grobów | Rzadki | 15% | 1 |
| Łuk milczącej krypty | Bardzo rzadki | 4% | 1 |

## Kamienny Strażnik

| Przedmiot | Rzadkość | Szansa | Liczba sztuk |
|---|---|---|---|
| Złote monety | Pospolity | 60% | 25–45 |
| Runiczne ostrze strażnika | Bardzo rzadki | 4% | 1 |
| Zbroja kamiennego strażnika | Bardzo rzadki | 4% | 1 |
| Hełm mchu i kamienia | Rzadki | 15% | 1 |
| Część Serca Świtu | Niezwykle rzadki | 100% (fabuła) | 1 |
| Esencja kniei | Rzadki | 15% | 1–2 |
| Kamień runiczny | Bardzo rzadki | 4% | 1 |
| Pierścień pradawnego echa | Niezwykle rzadki | 1% | 1 |
| Mikstura zdrowia | Pospolity | 60% | 1–2 |
| Mikstura many | Pospolity | 60% | 1–2 |
| Odłamek echa | Rzadki | 15% | 1 |
| Nagolenniki omszałych ruin | Rzadki | 15% | 1 |
| Tarcza pieczęci strażnika | Bardzo rzadki | 4% | 1 |
| Topór przebudzonej skały | Niezwykle rzadki | 1% | 1 |

## Dzik

| Przedmiot | Rzadkość | Szansa | Liczba sztuk |
|---|---|---|---|
| Złote monety | Pospolity | 60% | 4–15 |
| Kieł dzika | Pospolity | 60% | 1–2 |
| Skóra dzika | Pospolity | 60% | 1 |
| Mikstura zdrowia | Pospolity | 60% | 1 |
| Pancerz dziczej skóry | Rzadki | 15% | 1 |
| Topór dziczego kła | Bardzo rzadki | 4% | 1 |
| Buty dziczej skóry | Pospolity | 60% | 1 |
| Tarcza leśnego odyńca | Rzadki | 15% | 1 |
| Hełm odyńca | Bardzo rzadki | 4% | 1 |

## Leśny pająk

| Przedmiot | Rzadkość | Szansa | Liczba sztuk |
|---|---|---|---|
| Złote monety | Pospolity | 60% | 4–15 |
| Pajęcza nić | Pospolity | 60% | 1–3 |
| Woreczek jadu | Rzadki | 15% | 1 |
| Mikstura many | Pospolity | 60% | 1 |
| Buty pajęczego szlaku | Rzadki | 15% | 1 |
| Kaptur pajęczej nici | Rzadki | 15% | 1 |
| Pierścień jadowitego splotu | Bardzo rzadki | 4% | 1 |
| Sztylet leśnego pająka | Pospolity | 60% | 1 |
| Szata tkacza pajęczyn | Rzadki | 15% | 1 |
| Płaszcz nocnego jedwabiu | Niezwykle rzadki | 1% | 1 |

## Leśny rozbójnik

| Przedmiot | Rzadkość | Szansa | Liczba sztuk |
|---|---|---|---|
| Złote monety | Pospolity | 60% | 4–15 |
| Odznaka rozbójnika | Rzadki | 15% | 1 |
| Sztylet łowcy | Rzadki | 15% | 1 |
| Mikstura zdrowia | Pospolity | 60% | 1–2 |
| Łuk leśnego rozbójnika | Rzadki | 15% | 1 |
| Buty cichego kroku | Rzadki | 15% | 1 |
| Strzały | Pospolity | 60% | 5–10 |
| Szabla leśnego rabusia | Pospolity | 60% | 1 |
| Hełm z leśnej zasadzki | Rzadki | 15% | 1 |
| Sygnet króla bezdroży | Bardzo rzadki | 4% | 1 |

## Ożywione drzewo

| Przedmiot | Rzadkość | Szansa | Liczba sztuk |
|---|---|---|---|
| Złote monety | Pospolity | 60% | 4–15 |
| Prastara kora | Pospolity | 60% | 1–3 |
| Esencja kniei | Rzadki | 15% | 1 |
| Kamień runiczny | Bardzo rzadki | 4% | 1 |
| Tarcza prastarych korzeni | Rzadki | 15% | 1 |
| Amulet serca kniei | Bardzo rzadki | 4% | 1 |
| Hełm starej kory | Pospolity | 60% | 1 |
| Buty splecionych korzeni | Rzadki | 15% | 1 |
| Łuk przebudzonej kniei | Niezwykle rzadki | 1% | 1 |

## Skorpion bursztynowy

| Przedmiot | Rzadkość | Szansa | Liczba sztuk |
|---|---|---|---|
| Złote monety | Pospolity | 60% | 10–24 |
| Żądło skorpiona | Pospolity | 60% | 1–2 |
| Woreczek jadu | Rzadki | 15% | 1 |
| Mikstura zdrowia | Pospolity | 60% | 1 |
| Mikstura many | Pospolity | 60% | 1 |
| Sztylet bursztynowego żądła | Rzadki | 15% | 1 |
| Topór pustynnego żądła | Pospolity | 60% | 1 |
| Tarcza bursztynowego żądła | Rzadki | 15% | 1 |
| Pierścień pustynnego bursztynu | Bardzo rzadki | 4% | 1 |

## Skarabeusz miedziany

| Przedmiot | Rzadkość | Szansa | Liczba sztuk |
|---|---|---|---|
| Złote monety | Pospolity | 60% | 8–22 |
| Pancerz skarabeusza | Pospolity | 60% | 1–3 |
| Odłamek echa | Rzadki | 15% | 1 |
| Hełm miedzianego skarabeusza | Rzadki | 15% | 1 |
| Strzały | Pospolity | 60% | 5–10 |
| Zbroja pustynnego skarabeusza | Bardzo rzadki | 4% | 1 |
| Tarcza pustynnego monolitu | Bardzo rzadki | 4% | 1 |
| Buty miedzianego szlaku | Pospolity | 60% | 1 |
| Topór pancernej skorupy | Rzadki | 15% | 1 |
| Sygnet słonecznego skarabeusza | Niezwykle rzadki | 1% | 1 |

## Kobra piaskowa

| Przedmiot | Rzadkość | Szansa | Liczba sztuk |
|---|---|---|---|
| Złote monety | Pospolity | 60% | 8–20 |
| Łuska kobry | Pospolity | 60% | 1–3 |
| Woreczek jadu | Rzadki | 15% | 1 |
| Mikstura zdrowia | Pospolity | 60% | 1 |
| Buty piaskowej kobry | Rzadki | 15% | 1 |
| Pierścień jadowitego splotu | Bardzo rzadki | 4% | 1 |
| Łuk pustynnego mirażu | Bardzo rzadki | 4% | 1 |
| Płaszcz piaskowych łusek | Pospolity | 60% | 1 |
| Tarcza złocistej kobry | Rzadki | 15% | 1 |
| Amulet władcy węży | Niezwykle rzadki | 1% | 1 |

## Żywa Wydma

| Przedmiot | Rzadkość | Szansa | Liczba sztuk |
|---|---|---|---|
| Złote monety | Pospolity | 60% | 60–110 |
| Ostrze żywej wydmy | Niezwykle rzadki | 1% | 1 |
| Esencja piasku | Bardzo rzadki | 4% | 2–4 |
| Mikstura many | Pospolity | 60% | 1–3 |
| Część Serca Świtu | Niezwykle rzadki | 100% (fabuła) | 1 |
| Płaszcz piaskowej burzy | Niezwykle rzadki | 1% | 1 |
| Tarcza pustynnego monolitu | Bardzo rzadki | 4% | 1 |
| Amulet palącego słońca | Bardzo rzadki | 4% | 1 |
| Łuk pustynnego mirażu | Bardzo rzadki | 4% | 1 |
| Mikstura zdrowia | Pospolity | 60% | 1–3 |
| Odłamek echa | Rzadki | 15% | 1 |
| Buty wędrującej wydmy | Rzadki | 15% | 1 |
| Hełm serca pustyni | Bardzo rzadki | 4% | 1 |
| Łuk ostatniej jutrzenki | Niezwykle rzadki | 1% | 1 |

## Nowe wyposażenie

64 tematyczne przedmioty (w tym 36 dodanych 27.10.2026) korzystają z sześciu zwykłych slotów sprzętu. Bronie można przeciągać z plecaka na koło broni. Wszystkie nowe miecze obsługują Mocne cięcie; wszystkie nowe łuki obsługują naciąg, ograniczoną amunicję, celownik, kołczan i Przeszywającą strzałę. Topory i sztylety działają jako broń do walki wręcz.

| Przedmiot | Slot | Bonus bazowy | Opis |
|---|---|---|---|
| Sztylet wilczego kła | broń | atak +12 | Ostrze oprawione w srebrzysty wilczy kieł. |
| Płaszcz tropiciela | zbroja | pancerz +7 | Ciepły płaszcz z futra leśnych wilków. |
| Łuk księżycowego łowcy | broń | atak +19 | Łuk z jasnego drewna i wilczej cięciwy. |
| Pancerz dziczej skóry | zbroja | pancerz +8 | Skórzany pancerz wzmocniony dziczymi kłami. |
| Topór dziczego kła | broń | atak +17 | Ciężkie ostrze z okuciem w kształcie kła. |
| Buty pajęczego szlaku | buty | pancerz +5 | Lekkie buty obszyte mocną pajęczą nicią. |
| Pierścień jadowitego splotu | ozdoba | atak +7 | Srebrny pierścień z zielonym kamieniem. |
| Kaptur pajęczej nici | hełm | pancerz +6 | Kaptur tkany z nici leśnych pająków. |
| Hełm kościanej straży | hełm | pancerz +6 | Stalowy hełm z rzeźbionymi okuciami. |
| Miecz zapomnianej krypty | broń | atak +17 | Stare ostrze pokryte błękitnymi runami. |
| Łuk leśnego rozbójnika | broń | atak +17 | Krótki łuk ze skóry i ciemnego drewna. |
| Buty cichego kroku | buty | pancerz +6 | Wysokie buty z miękkiej leśnej skóry. |
| Tarcza prastarych korzeni | tarcza | pancerz +7 | Splecione korzenie chronią przed ciosami. |
| Amulet serca kniei | ozdoba | atak +8 | Bursztyn zamknięty w żywych korzeniach. |
| Amulet szmaragdowej kropli | ozdoba | atak +5 | Zastygła kropla esencji leśnego szlama. |
| Runiczne ostrze strażnika | broń | atak +19 | Kamienny strażnik chronił runy tego miecza. |
| Zbroja kamiennego strażnika | zbroja | pancerz +12 | Płyty pancerza z pradawnego kamienia. |
| Hełm mchu i kamienia | hełm | pancerz +8 | Kamienne okucia oplecione zielonym mchem. |
| Pierścień pradawnego echa | ozdoba | atak +11 | Fioletowy kryształ pamięta dawne ruiny. |
| Sztylet bursztynowego żądła | broń | atak +14 | Smukłe ostrze w kształcie żądła skorpiona. |
| Hełm miedzianego skarabeusza | hełm | pancerz +8 | Miedziany hełm z ornamentem skarabeusza. |
| Zbroja pustynnego skarabeusza | zbroja | pancerz +11 | Miedziane płytki zachodzą na siebie jak łuski. |
| Buty piaskowej kobry | buty | pancerz +7 | Giętkie buty ze złocistych łusek kobry. |
| Łuk pustynnego mirażu | broń | atak +22 | Złocisty łuk zdobiony pustynnymi runami. |
| Amulet palącego słońca | ozdoba | atak +9 | Bursztynowe słońce w miedzianej oprawie. |
| Ostrze żywej wydmy | broń | atak +25 | Piasek krąży wokół klingi pustynnego bossa. |
| Płaszcz piaskowej burzy | zbroja | pancerz +16 | Złote nici migoczą jak nawiewany piasek. |
| Tarcza pustynnego monolitu | tarcza | pancerz +10 | Kamienna tarcza z ornamentem wydmy. |
| Ostrze zielonej kropli | broń | atak +7 | Proste ostrze pokryte zaschniętą esencją. |
| Kaptur mglistego runa | hełm | pancerz +5 | Kaptur chroniący przed leśną wilgocią. |
| Pierścień bursztynowego żelu | ozdoba | atak +6 | Przejrzysta kropla w bursztynowej oprawie. |
| Kaptur szarego wilka | hełm | pancerz +3 | Szare futro chroni głowę wędrowca. |
| Buty srebrnego tropu | buty | pancerz +5 | Srebrzysta sierść osłania skórzane cholewy. |
| Amulet wilczego serca | ozdoba | atak +10 | Księżycowy kamień w oprawie z kłów. |
| Tarcza kościanych odłamków | tarcza | pancerz +4 | Dębowa tarcza wzmocniona białą kością. |
| Pancerz strażnika grobów | zbroja | pancerz +7 | Kościane płytki na ciemnej kolczudze. |
| Łuk milczącej krypty | broń | atak +18 | Kościane ramiona zdobione zimnymi runami. |
| Nagolenniki omszałych ruin | buty | pancerz +8 | Kamienne okucia oplecione młodym mchem. |
| Tarcza pieczęci strażnika | tarcza | pancerz +10 | Runiczna płyta z dawnej bramy ruin. |
| Topór przebudzonej skały | broń | atak +24 | W kamiennej głowicy pulsuje pradawny żar. |
| Buty dziczej skóry | buty | pancerz +3 | Gruba skóra i mocne rzemienie. |
| Tarcza leśnego odyńca | tarcza | pancerz +6 | Zaokrąglona tarcza okutą parą kłów. |
| Hełm odyńca | hełm | pancerz +9 | Dwa jasne kły chronią skronie wojownika. |
| Sztylet leśnego pająka | broń | atak +8 | Lekkie ostrze oplecione mocną nicią. |
| Szata tkacza pajęczyn | zbroja | pancerz +8 | Gęsta pajęcza tkanina i srebrne przeszycia. |
| Płaszcz nocnego jedwabiu | zbroja | pancerz +14 | Ciemne nici migoczą fioletowym blaskiem. |
| Szabla leśnego rabusia | broń | atak +9 | Wyszczerbiona klinga z ciemną rękojeścią. |
| Hełm z leśnej zasadzki | hełm | pancerz +6 | Ciemna stal skryta pod skórzanym kapturem. |
| Sygnet króla bezdroży | ozdoba | atak +7 | Sygnet z bursztynem znalezionym w łupach. |
| Hełm starej kory | hełm | pancerz +4 | Twarda kora spięta miedzianymi obręczami. |
| Buty splecionych korzeni | buty | pancerz +6 | Elastyczne korzenie osłaniają stopy. |
| Łuk przebudzonej kniei | broń | atak +23 | Żywe drewno przechowuje światło starego lasu. |
| Topór pustynnego żądła | broń | atak +11 | Bursztynowa głowica z twardego pancerza. |
| Tarcza bursztynowego żądła | tarcza | pancerz +7 | Wygięte płyty osłaniają przed ciosami. |
| Pierścień pustynnego bursztynu | ozdoba | atak +8 | W złotym bursztynie zastygła kropla jadu. |
| Buty miedzianego szlaku | buty | pancerz +4 | Miedziane blaszki na piaskowej skórze. |
| Topór pancernej skorupy | broń | atak +16 | Miedziany skarabeusz zdobi szerokie ostrze. |
| Sygnet słonecznego skarabeusza | ozdoba | atak +10 | Złoty owad strzeże fioletowego kryształu. |
| Płaszcz piaskowych łusek | zbroja | pancerz +6 | Piaskowa tkanina z warstwą drobnych łusek. |
| Tarcza złocistej kobry | tarcza | pancerz +8 | Złociste łuski zachodzą na siebie jak płytki. |
| Amulet władcy węży | ozdoba | atak +11 | Oko kobry lśni w oprawie z łusek. |
| Buty wędrującej wydmy | buty | pancerz +10 | Piaskowe okucia chronią przed gorącem. |
| Hełm serca pustyni | hełm | pancerz +12 | Kamienna korona z rozżarzonym bursztynem. |
| Łuk ostatniej jutrzenki | broń | atak +27 | Złociste ramiona rozświetla chłodny żar. |

## Włócznie

| Broń | Premia ataku | Rzadkość | Źródło | Szansa |
|---|---:|---|---|---:|
| Włócznia jesionowa | +13 | Pospolita | Leśny rozbójnik | 60% |
| Włócznia cierni kniei | +18 | Rzadka | Ożywione drzewo | 15% |
| Włócznia bursztynowej oazy | +21 | Rzadka | Skorpion bursztynowy | 15% |
| Włócznia bazaltowego grotu | +25 | Bardzo rzadka | Obsydianowy wojownik | 4% |
| Włócznia Ostatniego Świtu | +31 | Niezwykle rzadka | Varkhor, Serce Kaldery | 1% |

## Zgodność zapisów — rozszerzenie 27.10.2026

Łącznie dostępnych jest 75 elementów wyposażenia. Stare identyfikatory przedmiotów i zapisy pozostają zgodne. Istniejące ciała zachowują swój wcześniej wylosowany łup; nowe przedmioty mogą wypaść z kolejnych zabitych bestii. Każdy gatunek zyskał trzy dodatkowe pozycje, bez zmiany procentów rzadkości ani gwarantowanych fragmentów fabularnych.
