# Zależności i zasoby

- **raylib 5.5**, Ramon Santamaria i współtwórcy, licencja zlib: https://github.com/raysan5/raylib/blob/5.5/LICENSE . Pełna licencja jest dołączona w `assets/licenses/raylib-LICENSE.txt`.
- **Manrope**, Mikhail Sharanda i współtwórcy, SIL Open Font License 1.1. Pełna licencja: `assets/Manrope-LICENSE.txt`. Źródło: https://github.com/google/fonts/tree/main/ofl/manrope .
- **Lato**, Łukasz Dziedzic, SIL Open Font License 1.1. Pełna licencja: `assets/Lato-LICENSE.txt`. Źródło: https://github.com/google/fonts/tree/main/ofl/lato .
- **Cinzel**, Natanael Gama, SIL Open Font License 1.1. Pełna licencja: `assets/Cinzel-LICENSE.txt`. Źródło: https://github.com/google/fonts/tree/main/ofl/cinzel .
  `assets/Cinzel-Bold.ttf` to lokalnie utrwalona odmiana o wadze 700 z dołączonego fontu zmiennego, na tej samej licencji OFL. Proces i hashe: `art/typography/provenance.json`.
- **w64devkit 2.0.0 / MinGW-w64** — narzędzia kompilacji, osobne licencje w folderze `tools/w64devkit`. Licencje runtime dystrybuowanego z plikiem EXE znajdują się w `assets/licenses/`.
- Grafiki i kod gry Emberfall powstały dla tego projektu. Nie zawierają grafik z Tibii.
- Otoczenie Kaldery w `assets/volcano/` oraz bazowe części przeciwników są
  oryginalnymi ilustracjami 2D wykonanymi w Kricie dla Emberfall. Animacje
  pochodzą z lokalnego Synfiga. Otoczenie nie używa zewnętrznych obrazów,
  modeli ani płatnych usług. Detale scenografii i płynąca lawa:
  `art/volcano/river-detail/README.md`; poprzednia warstwa:
  `art/volcano/polish/README.md`.
- Siedem atlasów przeciwników Kaldery (`slag-crawler`, `lava-salamander`,
  `fire-imp`, `ash-wraith`, `obsidian-sentinel`, `ember-drake`, `varkhor`)
  zawiera od 04.11.2026 malowanie materiałów wygenerowane lokalnie w ComfyUI
  na podstawie własnych części projektu. Model **DreamShaper 8**, Lykon:
  https://huggingface.co/Lykon/DreamShaper oraz
  https://civitai.com/models/4384/dreamshaper . Opublikowane uprawnienia autora
  dopuszczają komercyjne wykorzystanie wygenerowanych obrazów (`Image`)
  i modyfikacje; zachowano kopię metadanych licencji i SHA-256 modelu.
  Nie rozpowszechniamy wag modelu w grze. Generowanie nie korzysta z płatnych
  API ani wysyłania projektu do chmury. Źródła, workflow i pochodzenie:
  `art/volcano/comfy/README.md` i `provenance.json`.
- Odłamki `assets/sprites/guardian-fragments.png` powstały jako sześć oryginalnych warstw Krity; ich rozpad, obroty i odbicia opracowano w natywnym projekcie Synfig. Źródła i pochodzenie: `art/gameplay/guardian/shatter/`. Bez zewnętrznych grafik, modeli i płatnych usług.
- Duży głaz Strażnika `assets/sprites/guardian-stone.png` to własna sześciowarstwowa grafika z Krity, z ziemią i korzeniami; wyrwanie i oburęczny rzut znad głowy opracowano w natywnym projekcie 2D Synfig. Źródła i pochodzenie: `art/gameplay/guardian/`. Bez zewnętrznych grafik, modeli i płatnych usług.
- Ilustracja leśnej Bramy Świtu w `assets/menu/` została narysowana w Kricie dla Emberfall, a animacja warstw opracowana w Synfig Studio. Własne kształty i kolory, bez zewnętrznych obrazów, modeli, sampli i płatnych usług. Edytowalne źródła i pochodzenie: `art/menu/README.md`, `art/menu/forest/provenance.json`.
- Malowane detale bohatera `assets/sprites/hero-paints.png` powstały w Kricie, a dodatkowe krzywe animacji w Synfig Studio, wyłącznie z oryginalnych części projektu. Źródła i pochodzenie: `art/hero/README.md`. Bez zewnętrznych modeli, grafik ani płatnych usług.
- Leśny krzew `assets/sprites/forest-bush.png` został narysowany w Kricie dla Emberfall, bez zasobów zewnętrznych. Warstwowy master i pochodzenie: `art/scenery/README.md`.
- Świerk, brzoza i dąb w `assets/sprites/forest-{spruce,birch,oak}.png` to oryginalne warstwowe ilustracje narysowane natywnymi narzędziami Krity dla Emberfall. Bez zewnętrznych grafik, modeli i płatnych usług. Źródła i pochodzenie: `art/scenery/trees/`, `art/scenery/README.md`.
- Muzyka „Echoes of the Ruins” i 21 efektów w `assets/audio/` powstały dla tego projektu metodą syntezy, bez zewnętrznych nagrań i sampli. Można je rozpowszechniać z grą. Opis: `assets/audio/README.md`.

- Dwie pustynne fontanny w `assets/sprites/fountain-*.png` to oryginalne grafiki Emberfall narysowane na warstwach w Kricie. Wodę i opróżnianie animowano w lokalnym Synfigu. Bez zewnętrznych grafik, modeli, sampli i płatnych usług; można rozpowszechniać z grą. Natywne źródła i pochodzenie: `art/gameplay/fountains/`.

- Szczątki Żywej Wydmy w `assets/sprites/dune-fallen.png` to oryginalna warstwowa grafika Emberfall narysowana w Kricie w ośmiu kierunkach. Bez zewnętrznych obrazów, modeli i płatnych usług; można rozpowszechniać z grą. Master KRA i pochodzenie: `art/gameplay/dune-fallen/`.

- Panorama Doliny Świtu i dwie warstwy balkonu w `assets/sprites/tower-{valley,balcony-back,balcony-front}.png` to własne ilustracje Emberfall narysowane natywnymi narzędziami Krity. Bez zewnętrznych obrazów, modeli i płatnych usług; można rozpowszechniać z grą. Warstwowe źródła KRA i pochodzenie: `art/scenery/tower-balcony/README.md`, `art/scenery/tower-balcony/provenance.json`.
